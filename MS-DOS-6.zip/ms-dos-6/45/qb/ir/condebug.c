/*** 
*condebug.c - non-release code to validate context.asm
*
*  Copyright <C> 1986, Microsoft Corporation
*
*Purpose:
*  contains routines used for debugging the context manager.
*
*******************************************************************************/
#include "version.h"
