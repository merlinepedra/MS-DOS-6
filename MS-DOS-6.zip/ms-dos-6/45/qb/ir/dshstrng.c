/*** 
*dshstrngs.c - print strings for dumb shell debug command processor
*
*	Copyright <C> 1985, 1986, 1987 Microsoft Corporation
*
*Purpose:
*	For versions of QB-technology based BASIC built without the real user-
*	interface.
*
*******************************************************************************/

#include "version.h"

#if !SCANNER_H
#include "scanner.h"
#endif

#if !UI_H
#include "ui.h"
#endif
