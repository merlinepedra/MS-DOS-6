char FARPRIVATE ChUpperFromChExt(char);
