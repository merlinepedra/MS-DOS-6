/*
	COW : Character Oriented Windows

	medit.h : multi-line edit item
*/

/*****************************************************************************/

VOID	FARPUBLIC InitEditWnd(PWND, BYTE *, WORD);


/*****************************************************************************/
