#define CC
#define IBM_COLORS
#define HELP_BUTTON

#define cwExtraWnd	2

#include <cw\cwindows.h>
