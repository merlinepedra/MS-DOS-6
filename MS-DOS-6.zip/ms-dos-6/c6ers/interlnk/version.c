/***
* $Workfile:   version.c  $
* $Revision:   1.1  $
*   $Author:   Dave Sewell  $
*     $Date:   27 Jun 1989 14:54:44  $
***/

/*** Variables configurable at program build time. ***/

char cdecl version[] = VERSION;


