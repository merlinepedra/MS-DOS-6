extern void pascal Bell(void);
extern	void _far pascal GetDosCountryInfo(void *);
extern	void _fastcall FormatDateString(char *buffer, struct dosdate_t *dateptr);
extern	void FormatTimeString(char *buffer, struct dostime_t *time);

